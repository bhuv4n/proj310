<?php
$conn = mysqli_connect("localhost", "root", "YES", "fast_travel");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
